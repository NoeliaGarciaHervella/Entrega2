-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 27-10-2019 a las 23:06:43
-- Versión del servidor: 10.4.6-MariaDB
-- Versión de PHP: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `mydal`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carpeta`
--

CREATE TABLE `carpeta` (
  `ID_CARPETA` int(10) NOT NULL,
  `NOMBRE` varchar(255) COLLATE latin1_spanish_ci NOT NULL,
  `PROPIETARIO` int(10) NOT NULL,
  `PADRE` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `carpeta`
--

INSERT INTO `carpeta` (`ID_CARPETA`, `NOMBRE`, `PROPIETARIO`, `PADRE`) VALUES
(1, 'TSW', 1, NULL),
(2, 'Primera entrega', 1, 1),
(3, 'Segunda entrega', 1, 1),
(4, 'ABP', 1, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fichero`
--

CREATE TABLE `fichero` (
  `ID_FICHERO` int(10) NOT NULL,
  `NOMBRE` varchar(255) COLLATE latin1_spanish_ci NOT NULL,
  `PROPIETARIO` int(10) NOT NULL,
  `PADRE` int(10) DEFAULT NULL,
  `FORMATO` varchar(255) COLLATE latin1_spanish_ci NOT NULL,
  `COMPARTIR` enum('SI','NO') COLLATE latin1_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `fichero`
--

INSERT INTO `fichero` (`ID_FICHERO`, `NOMBRE`, `PROPIETARIO`, `PADRE`, `FORMATO`, `COMPARTIR`) VALUES
(1, 'primerdiagrama.jpg', 1, 4, 'image/jpeg', 'NO');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `ID_USUARIO` int(10) NOT NULL,
  `USERNAME` varchar(255) COLLATE latin1_spanish_ci NOT NULL,
  `PASSWD` varchar(255) COLLATE latin1_spanish_ci NOT NULL,
  `EMAIL` varchar(255) COLLATE latin1_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`ID_USUARIO`, `USERNAME`, `PASSWD`, `EMAIL`) VALUES
(1, 'Noelia', 'holahola', 'nghervella@esei.uvigo.es');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `carpeta`
--
ALTER TABLE `carpeta`
  ADD PRIMARY KEY (`ID_CARPETA`),
  ADD KEY `FK_PROPIETARIO` (`PROPIETARIO`),
  ADD KEY `PADRE` (`PADRE`);

--
-- Indices de la tabla `fichero`
--
ALTER TABLE `fichero`
  ADD PRIMARY KEY (`ID_FICHERO`),
  ADD KEY `FK_PADRE` (`PADRE`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`ID_USUARIO`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `carpeta`
--
ALTER TABLE `carpeta`
  MODIFY `ID_CARPETA` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `fichero`
--
ALTER TABLE `fichero`
  MODIFY `ID_FICHERO` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `ID_USUARIO` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `carpeta`
--
ALTER TABLE `carpeta`
  ADD CONSTRAINT `FK_PROPIETARIO` FOREIGN KEY (`PROPIETARIO`) REFERENCES `usuario` (`ID_USUARIO`) ON DELETE CASCADE,
  ADD CONSTRAINT `carpeta_ibfk_1` FOREIGN KEY (`PADRE`) REFERENCES `carpeta` (`ID_CARPETA`) ON DELETE CASCADE;

--
-- Filtros para la tabla `fichero`
--
ALTER TABLE `fichero`
  ADD CONSTRAINT `FK_PADRE` FOREIGN KEY (`PADRE`) REFERENCES `carpeta` (`ID_CARPETA`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
